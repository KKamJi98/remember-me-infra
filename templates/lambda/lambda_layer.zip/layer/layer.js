module.exports = {
  helloWorld: () => {
    return "Hello from the Lambda layer!";
  }
};